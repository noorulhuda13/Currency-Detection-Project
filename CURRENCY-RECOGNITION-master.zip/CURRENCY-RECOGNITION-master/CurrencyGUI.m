function MY()

clc;

handles = MY_GUI();

set(handles.btnBrowse,'Callback',@browse_input_Callback);
set(handles.btnRecognition,'Callback',@recognition_Callback);
set(handles.btnClear,'Callback',@clear_all_Callback);
set(handles.btnExit,'Callback',@exit_Callback);

guidata(handles.figure,handles);

end


%% Browse Input
function browse_input_Callback(src,~)

handles = guidata(src);

[filename, pathname] = uigetfile( ...
    {'*.jpg;*.png;*.jpeg','Image Files'});

if isequal(filename,0)
    return;
end

fullpath = fullfile(pathname,filename);

img = imread(fullpath);

axes(handles.axes1);
imshow(img);

handles.input_image = img;

guidata(handles.figure,handles);

set(handles.statusText,'String','Image Loaded Successfully');

end


%% Recognition
function recognition_Callback(src,~)

handles = guidata(src);

if ~isfield(handles,'input_image')

    errordlg('Please Browse Image First');

    return;

end

set(handles.text1,'String','Dollar');
set(handles.text2,'String','USA');
set(handles.text3,'String','100 USD');

set(handles.statusText,'String','Recognition Complete');

end


%% Clear
function clear_all_Callback(src,~)

handles = guidata(src);

cla(handles.axes1);
cla(handles.axes2);

set(handles.text1,'String','');
set(handles.text2,'String','');
set(handles.text3,'String','');

set(handles.statusText,'String','Waiting for input...');

guidata(handles.figure,handles);

end


%% Exit
function exit_Callback(~,~)

close gcf;

end