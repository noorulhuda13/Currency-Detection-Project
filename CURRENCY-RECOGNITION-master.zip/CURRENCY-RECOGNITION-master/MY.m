function MY()
    clc;
    handles = MY_GUI(); 
    
    set(handles.btnBrowse, 'Callback', @browse_Callback);
    set(handles.btnAnalyze, 'Callback', @analyze_Callback);
    set(handles.btnClear, 'Callback', @clear_all_Callback);
    set(handles.btnExit, 'Callback', @(s,e) close(gcf));
    
    types = {'orig','filt','noise','enhan','edge','seg','morph'};
    btns = {handles.btn1, handles.btn2, handles.btn3, handles.btn4, handles.btn5, handles.btn6, handles.btn7};
    for i=1:7
        set(btns{i}, 'Callback', @(s,e) update_view(s, types{i}));
    end
    
    guidata(handles.figure, handles);
end

function browse_Callback(src, ~)
    handles = guidata(src);
    [n, p] = uigetfile({'*.jpg;*.png;*.jpeg'}, 'Select Currency Note');
    if isequal(n, 0), return; end
    
    handles.img_orig = imread(fullfile(p, n));
    axes(handles.axes1); imshow(handles.img_orig); title('1. Input Note');
    
    set([handles.resName, handles.resCountry, handles.resMSE, handles.resPSNR], 'String', '');
    cla(handles.axes2);
    guidata(handles.figure, handles);
end

function analyze_Callback(src, ~)
    handles = guidata(src);
    if ~isfield(handles, 'img_orig'), errordlg('Pehle image browse karein!'); return; end
    
    try
        % --- PROCESSING PIPELINE ---
        im = imresize(handles.img_orig, [128 128]);
        
        % Step 2: Filtered (Denoising)
        r = medfilt2(im(:,:,1)); g = medfilt2(im(:,:,2)); b = medfilt2(im(:,:,3));
        handles.img_filt = cat(3, r, g, b);
        
        % --- QUALITY METRICS CALCULATION (NEW) ---
        % Convert to double for math
        orig_d = double(im);
        filt_d = double(handles.img_filt);
        
        % 1. Mean Squared Error (MSE)
        mse_val = mean((orig_d(:) - filt_d(:)).^2);
        set(handles.resMSE, 'String', sprintf('%.4f', mse_val));
        
        % 2. Peak Signal-to-Noise Ratio (PSNR)
        if mse_val > 0
            psnr_val = 10 * log10(255^2 / mse_val);
            set(handles.resPSNR, 'String', sprintf('%.2f dB', psnr_val));
        else
            set(handles.resPSNR, 'String', 'Inf (Perfect)');
        end
        
        % Step 3: Noise Map
        handles.img_noise = imabsdiff(im, handles.img_filt) * 25;
        
        % Step 4: Enhanced (Luv/Histeq)
        hsv = rgb2hsv(handles.img_filt); hsv(:,:,3) = histeq(hsv(:,:,3));
        handles.img_enhan = hsv2rgb(hsv);
        
        % Step 5: Edges (Binary)
        gray_im = rgb2gray(handles.img_enhan);
        handles.img_edge = edge(gray_im, 'sobel');
        
        % Step 6: Segmentation (Binary)
        handles.img_seg = imbinarize(gray_im);
        
        % Step 7: Morphological Clean (Binary)
        handles.img_morph = imopen(handles.img_seg, strel('disk', 1));
        
        % --- RECOGNITION LOGIC ---
        fet = totalfeature(handles.img_filt); 
        if ~exist('projectdb.mat', 'file'), errordlg('projectdb.mat missing!'); return; end
        load('projectdb.mat', 'my_database');
        
        D = arrayfun(@(x) norm(fet - x.feature), my_database);
        [min_val, idx] = min(D);
        
        db_map = {
            'Australian Dollar', 'Australia', '100 AUD', 'australiaf.jpg';
            'Danish Krone', 'Denmark', '500 DKK', 'Denmarkf.jpg';
            'Dollar', 'USA', '100 USD', 'usaf.jpg';
            'Egyptian Pound', 'Egypt', '100 EGP', 'egypt.jpg';
            'Euro', 'France', '50 EUR', 'francef.jpg';
            'Icelandic króna', 'IceLand', '5000 ISK', 'Icelandf.jpg';
            'Rupee', 'India', '500 INR', 'indiaf.jpg';
            'Indonesian Rupiah', 'Indonesia', '100000 IDR', 'indonesiaf.jpg';
            'Iranian Rial', 'Iran', '50000 IRR', 'iranf.jpg';
            'Won', 'South Korea', '1000 KRW', 'koreaf.jpg';
            'Malaysian Ringgit', 'Malaysia', '100 MYR', 'malaysiaf.jpg';
            'Yen', 'Japan', '1000 JPY', 'chinaf.jpg';
            'Russian Rouble', 'Russia', '5000 RUB', 'russiaf.jpg';
            'Saudi riyal', 'Saudi Arabia', '500 SAR', 'saudif.jpg';
            'South African rand', 'South Africa', '200 ZAR', 'africaf.jpg';
            'Swiss franc', 'Switzerland', '1000 CHF', 'sf.jpg';
            'Turkish lira', 'Turkey', '200 TRY', 'turkeyf.jpg'
        };
        
        if min_val < 20000
            set(handles.resName, 'String', db_map{idx, 1});
            set(handles.resCountry, 'String', db_map{idx, 2});
            axes(handles.axes2);
            flagPath = fullfile(pwd, 'currenyf', db_map{idx, 4});
            if exist(flagPath, 'file'), imshow(flagPath); end
        else
            set(handles.resName, 'String', 'Not Recognized');
        end
        
        guidata(handles.figure, handles);
        msgbox(['Analysis Complete! PSNR: ' get(handles.resPSNR, 'String')]);
        
    catch ME
        errordlg(['Error: ' ME.message]);
    end
end

function update_view(src, type)
    handles = guidata(src);
    if ~isfield(handles, 'img_filt'), return; end
    axes(handles.axes1);
    switch type
        case 'orig', img = handles.img_orig; lbl = '1. Original';
        case 'filt', img = handles.img_filt; lbl = '2. Filtered';
        case 'noise', img = handles.img_noise; lbl = '3. Noise Map';
        case 'enhan', img = handles.img_enhan; lbl = '4. Enhanced';
        case 'edge', img = handles.img_edge; lbl = '5. Edges';
        case 'seg', img = handles.img_seg; lbl = '6. Segmented';
        case 'morph', img = handles.img_morph; lbl = '7. Cleaned';
    end
    imshow(img); title(lbl);
    
    axes(handles.axesGraph); cla;
    if size(img,3) == 3, sig = rgb2gray(img); else, sig = img; end
    val = mean(double(sig));
    if islogical(sig) || max(sig(:)) <= 1, val = val * 255; end
    plot(val, 'LineWidth', 2, 'Color', [0.8 0 0]);
    grid on; ylim([0 260]); title(['Profile: ', lbl]);
end

function clear_all_Callback(src, ~)
    handles = guidata(src);
    cla(handles.axes1); cla(handles.axes2); cla(handles.axesGraph);
    set([handles.resName, handles.resCountry, handles.resMSE, handles.resPSNR], 'String', '');
end