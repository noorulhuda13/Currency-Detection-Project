notesPath = fullfile(pwd, 'currenynotes');
imgFiles = {
    'australiandollar.jpg', 'danish krone.jpg', 'dollar.jpg', ...
    'egyptian pound.jpg', 'france euro.jpg', 'Iceland_Currency_krona.jpg', ...
    'indianrupee.jpg', 'indonesia.jpg', 'iran.jpg', 'korea.jpg', ...
    'malaysia.jpg', 'yen.jpg', 'russia rouble.jpg', ...
    'saud-arabia1.jpg', 'soth africa.jpg', 'Switzerland 1000 Franken.jpg', ...
    'turkey.jpg'
};

my_database = struct();
for j = 1:length(imgFiles)
    im = imread(fullfile(notesPath, imgFiles{j}));
    im = imresize(im, [128 128]);
    
    % Denoise each channel
    r = medfilt2(im(:,:,1));
    g = medfilt2(im(:,:,2));
    b = medfilt2(im(:,:,3));
    rgbim = cat(3, r, g, b);
    
    fet = totalfeature(rgbim);
    my_database(j).feature = fet;
end

save('projectdb.mat', 'my_database');
disp('projectdb.mat rebuilt successfully!');